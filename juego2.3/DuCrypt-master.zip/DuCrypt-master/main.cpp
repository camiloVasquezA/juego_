#include <QCoreApplication>
#include <QDebug>
#include "DuCrypt.h"

int main(int argc, char *argv[])
{
	QCoreApplication a(argc, argv);
    DuCrypt crypt;
    crypt.setPassword("!@#$%^&*()_kjnklawh!@ucoi9293");
    crypt.setSalt("#$%^&!*@y9sg08dfsdfs");
    QString encryptedString = crypt.encrypt("This is my secret :)");
    qDebug() << encryptedString;
    qDebug() << crypt.decrypt(encryptedString);
	return a.exec();
}
